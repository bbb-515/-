from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    GENDER_CHOICES = [
        ('unknown', '未知'),
        ('male', '男'),
        ('female', '女'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default='unknown')
    level = models.IntegerField(default=1)
    activity_points = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        self.level = self.calculate_level()
        super(Profile, self).save(*args, **kwargs)

    def calculate_level(self):
        thresholds = [20, 300, 700, 1200, 1800, 2700, 66000]
        for i, threshold in enumerate(thresholds, start=1):
            if self.activity_points < threshold:
                return i
        return len(thresholds) + 1

from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    instance.profile.save()

class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='liked_posts', blank=True)
    bookmarks = models.ManyToManyField(User, related_name='bookmarked_posts', blank=True)
    views = models.IntegerField(default=0)
    bookmark_count = models.IntegerField(default=0)
    comments_count = models.IntegerField(default=0)
    def __str__(self):
        return self.content[:20]

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    parent_comment = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    likes = models.ManyToManyField(User, related_name='liked_comments', blank=True)
    like_count = models.IntegerField(default=0)
    reply_count = models.IntegerField(default=0)
    
    def __str__(self):
        return self.content[:20]

    def get_all_descendants(self):
        descendants = Comment.objects.filter(parent_comment=self)
        for child in descendants:
            descendants = descendants | child.get_all_descendants()
        return descendants

    def get_all_descendants_count(self):
        return self.get_all_descendants().count() + 1

    def delete_with_descendants(self):
        descendants = self.get_all_descendants()
        count = descendants.count() + 1
        descendants.delete()
        self.delete()
        return count

    
class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_notifications')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True, blank=True)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, null=True, blank=True)
    notification_type = models.CharField(max_length=10, choices=[('like', 'Like'), ('comment', 'Comment'), ('bookmark', 'Bookmark')])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender.username} {self.get_notification_type_display()} {self.user.username}"
    
class Report(models.Model):
    REPORT_CHOICES = [
        ('post', 'Post'),
        ('comment', 'Comment'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    report_type = models.CharField(max_length=10, choices=REPORT_CHOICES)
    report_id = models.IntegerField()  # 存储被举报的帖子或评论的ID
    description = models.TextField(blank=True)  # 举报描述（可选）
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.report_type} - {self.report_id}'
    
class PrivateMessage(models.Model):
    sender = models.ForeignKey(User, related_name="sent_messages", on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name="received_messages", on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['timestamp']

#高博文start
#组队模块
from django import forms
from django.db import models
from django.contrib.auth.models import User

class Team(models.Model):
    name = models.CharField(max_length=255)  # 团队名称
    description = models.TextField(blank=True)  # 团队简介
    leader = models.ForeignKey(User, on_delete=models.CASCADE, related_name='led_teams')  # 队长
    members = models.ManyToManyField(User, related_name='teams')  # 队员
    max_members = models.IntegerField(default=5)  # 最大队员数
    created_at = models.DateTimeField(auto_now_add=True)  # 创建时间

    def is_full(self):
        return self.members.count() >= self.max_members

    def __str__(self):
        return self.name


class TeamRequest(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='requests')  # 请求加入的队伍
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='team_requests')  # 请求用户
    message = models.TextField(blank=True)  # 请求说明
    status = models.CharField(
        max_length=10, 
        choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')],
        default='pending'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} -> {self.team.name} ({self.status})"


class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ['name', 'description', 'max_members']  # 可以根据需要添加更多字段

class TeamRequest(models.Model):
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='requests')  # 请求加入的队伍
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='team_requests')  # 请求用户
    message = models.TextField(blank=True)  # 申请人自我描述
    status = models.CharField(
        max_length=10, 
        choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')],
        default='pending'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} -> {self.team.name} ({self.status})"

#李卓伦（拉黑）

    from django.db import models
from django.contrib.auth.models import User

class Blacklist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blacklisted_users')
    blocked_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blocked_by')

    def __str__(self):
        return f"{self.user.username} blocked {self.blocked_user.username}"

