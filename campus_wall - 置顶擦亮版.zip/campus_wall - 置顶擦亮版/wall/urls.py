from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
#高博文start
from .views import manage_team, remove_member, review_request
#高博文end

urlpatterns = [
    path('', views.home, name='home'),
    path('post/create/', views.create_post, name='create_post'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('post/<int:post_id>/like/', views.like_post, name='like_post'),
    path('post/<int:post_id>/comment/', views.comment_post, name='comment_post'),
    path('post/<int:post_id>/bookmark/', views.bookmark_post, name='bookmark_post'),
    path('post/<int:post_id>/report/', views.report_post, name='report_post'),
    path('user/<int:user_id>/', views.user_profile, name='user_profile'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('messages/', views.messages, name='messages'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('report_comment/<int:comment_id>/', views.report_comment, name='report_comment'),  
    path('delete_post/<int:post_id>/', views.delete_post, name='delete_post'),
    path('delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),
    path('comment_reply/<int:comment_id>/', views.comment_reply, name='comment_reply'),
    path('comment/<int:comment_id>/like/', views.like_comment, name='like_comment'),  
    path('chat/<int:user_id>/', views.chat_view, name='chat'),
    path('send_message/<int:user_id>/', views.send_message, name='send_message'),
    #高博文start
    path('team/<int:team_id>/', views.team_home, name='team_home'),
    path('team/<int:team_id>/manage/', views.manage_team, name='manage_team'),  # 管理团队
    path('team/<int:team_id>/remove/<int:member_id>/', views.remove_member, name='remove_member'),  # 移除队员
    path('team/request/<int:request_id>/<str:action>/', views.review_request, name='review_request'),  # 审核加入请求
    path('create_or_join_team/', views.create_or_join_team, name='create_or_join_team'),  # 创建或加入团队
    path('team/<int:team_id>/leave/', views.leave_team, name='leave_team'),  # 队员退出团队
    path('team/<int:team_id>/pending_request/', views.pending_request, name='pending_request'),
    #高博文end
    #wzx start
    path('chat/<int:user_id>/', views.chat_view, name='chat'),
    path('send_message/<int:user_id>/', views.send_message, name='send_message'),
    path('follow/<int:user_id>/', views.follow_user, name='follow_user'),
    path('unfollow/<int:user_id>/', views.unfollow_user, name='unfollow_user'), 
    #wzx end
    #李卓伦 start
    path('post/<int:post_id>/pin/', views.pin_post, name='pin_post'),
    path('post/<int:post_id>/refresh/', views.refresh_post, name='refresh_post'),
    path('post/<int:post_id>/unpin/', views.unpin_post, name='unpin_post'),
    path('unblock_user/<int:user_id>/', views.unblock_user, name='unblock_user'),
    path('user/<int:user_id>/block/', views.block_user, name='block_user')
    #李卓伦 end
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)







