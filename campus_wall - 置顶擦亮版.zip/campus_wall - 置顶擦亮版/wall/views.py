from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User  
from .models import Profile, Post, Comment, Bookmark,Notification,Report
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.conf import settings
from django.db.models import Q, Count
from .models import Blacklist 
from django.contrib.auth.models import AnonymousUser
import jieba
from django.utils.dateparse import parse_date
#lwb
from django.core.files.storage import FileSystemStorage
from datetime import timedelta


#wzx 修改了home函数
def home(request):
    query = request.GET.get('q', '')  # 搜索查询
    start_date = request.GET.get('start_date', '')
    end_date = request.GET.get('end_date', '')
    sort_by = request.GET.get('sort_by', '')  # 排序字段

    if isinstance(request.user, AnonymousUser):
        blocked_users = []
    else:
        blocked_users = Blacklist.objects.filter(user=request.user).values_list('blocked_user', flat=True)

    posts = Post.objects.exclude(author__id__in=blocked_users)

    # 搜索过滤
    if query:
        # 使用 jieba 进行分词
        words = jieba.cut(query)
        words_list = list(words)  # 将分词结果转换为列表

        # 基于分词后的每个词进行查询，使用 Q 对象进行动态查询
        q_objects = Q()  # 初始化一个空的 Q 对象，用于组合多个查询条件
        for word in words_list:
            q_objects |= Q(content__icontains=word) | Q(author__username__icontains=word)
        
        # 在原有的帖子基础上进行过滤，使用 Q 对象组合的查询条件
        posts = posts.filter(q_objects)
   
    # 时间过滤
    if start_date or end_date:
        try:
            if start_date:
                start_date_obj = parse_date(start_date)
                posts = posts.filter(created_at__date__gte=start_date_obj)
            if end_date:
                end_date_obj = parse_date(end_date)
                posts = posts.filter(created_at__date__lte=end_date_obj)
            if start_date and end_date and start_date_obj > end_date_obj:
                raise ValueError("开始日期不能晚于结束日期")
        except ValueError as e:
            return render(request, 'wall/home.html', {
                'error_message': str(e),
                'posts': posts,
            })

    # 排序
    if sort_by == 'likes':
        posts = posts.annotate(sort_value=Count('likes')).order_by('-sort_value', '-created_at')
    elif sort_by == 'views':
        posts = posts.order_by('-views', '-created_at')
    elif sort_by == 'bookmark_count':
        posts = posts.order_by('-bookmark_count', '-created_at')
    elif sort_by == 'comments_count':
        posts = posts.order_by('-comments_count', '-created_at')
    else:
        posts = posts.order_by('-created_at')  # 默认按时间从新到旧排序

         # 获取所有帖子，首先按是否置顶排序，然后按创建时间排序
    posts = Post.objects.all().order_by('-is_pinned', '-created_at')


    liked_posts = request.user.liked_posts.all() if request.user.is_authenticated else []
    bookmarked_posts = request.user.bookmarked_posts.all() if request.user.is_authenticated else []

    context = {
        'posts': posts,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
    }
    return render(request, 'wall/home.html', context)

#创建帖子
#lwb开始
import logging

logger = logging.getLogger(__name__)
#lwb结束
@login_required
def create_post(request):
    if request.method == 'POST':
        content = request.POST['content']
        image = request.FILES.get('image')  # 获取上传的图片文件lwb
        post = Post.objects.create(author=request.user, content=content)
        #lwb开始
        if image:  # 如果有图片上传
            fs = FileSystemStorage()  # 使用 Django 的文件存储系统
            filename = fs.save(image.name, image)  # 保存图片
            post.image_url = fs.url(filename)  # 保存图片URL到数据库
            logger.info(f"Image saved as {filename}, URL: {post.image_url}")
            post.save()  # 保存 post 对象，更新 image_url 字段
        #lwb结束
        request.user.profile.activity_points += 2
        request.user.profile.save()
        return redirect('post_detail', post_id=post.id)  # 确保重定向到帖子详情页
    else:
        # 处理 GET 请求，渲染发帖页面
        return render(request, 'wall/create_post.html')
#帖子详情页
@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.views += 1  # 增加帖子浏览量
    post.save()
    comments = Comment.objects.filter(post=post).order_by('created_at')
    liked_posts = request.user.liked_posts.all()
    bookmarked_posts = request.user.bookmarked_posts.all()
    liked_comments = request.user.liked_comments.all()

    context = {
        'post': post,
        'comments': comments,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
        'liked_comments': liked_comments,
    }
    return render(request, 'wall/post_detail.html', context)
#点赞和取消点赞/对帖子
@require_POST
@login_required
def like_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if post.author != request.user:
        if request.user in post.likes.all():
            post.likes.remove(request.user)
            liked = False
            #减活跃值
            post.author.profile.activity_points -= 1
            post.author.profile.save()
        else:
            post.likes.add(request.user)
            liked = True       
            Notification.objects.create(user=post.author, sender=request.user, post=post, notification_type='like')
            #减活跃值
            post.author.profile.activity_points += 1
            post.author.profile.save()
        return JsonResponse({'liked': liked, 'count': post.likes.count()})
    else:
        liked = False #不能给自己点赞
        return JsonResponse({'liked': liked, 'count': post.likes.count()})    
    
#点赞和取消点赞/对评论
@require_POST
@login_required
def like_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.author != request.user:
        if request.user in comment.likes.all():
            comment.likes.remove(request.user)
            liked = False
            comment.like_count -= 1
            #减活跃值
            comment.author.profile.activity_points -= 1
            comment.author.profile.save()
        else:
            comment.likes.add(request.user)
            liked = True
            comment.like_count += 1
            if comment.author != request.user:
                Notification.objects.create(user=comment.author, sender=request.user, comment=comment, notification_type='like')
            #加活跃值
            comment.author.profile.activity_points += 1
            comment.author.profile.save()
        comment.save()
        return JsonResponse({'liked': liked, 'count': comment.like_count})
    else:
        liked = False  # 不能给自己点赞
        return JsonResponse({'liked': liked, 'count': comment.like_count})
    
#收藏和取消收藏/对帖子
@require_POST
@login_required
def bookmark_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    bookmark, created = Bookmark.objects.get_or_create(user=request.user, post=post)
    if not created:
        #加活跃值
        bookmark.post.author.profile.activity_points += 1
        bookmark.post.author.profile.save()
        bookmark.delete()
        post.bookmarks.remove(request.user)
        post.bookmark_count -= 1
        bookmarked = False
    else:
        #减活跃值
        bookmark.post.author.profile.activity_points -= 1
        bookmark.post.author.profile.save()
        post.bookmarks.add(request.user)        
        post.bookmark_count += 1
        bookmarked = True
        Notification.objects.create(user=post.author, sender=request.user, post=post, notification_type='bookmark')
    post.save()
    return JsonResponse({'bookmarked': bookmarked, 'count': post.bookmark_count})


#评论/对帖子
@require_POST
@login_required
def comment_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        content = request.POST.get('content')
        #加活跃值
        request.user.profile.activity_points += 1
        request.user.profile.save()
        if content:
            comment = Comment.objects.create(post=post, author=request.user, content=content)
            if post.author != request.user:
                Notification.objects.create(user=post.author, sender=request.user, post=post, comment=comment, notification_type='comment')
            post.comments_count += 1
            post.save()
    return redirect('post_detail', post_id=post.id)

#评论/对评论
@login_required
def comment_reply(request, comment_id):
    parent_comment = get_object_or_404(Comment, id=comment_id)
    if request.method == 'POST':
        content = request.POST.get('content')
        #加活跃值
        request.user.profile.activity_points += 1
        request.user.profile.save()
        if content:
            new_comment = Comment.objects.create(
                post=parent_comment.post,
                author=request.user,
                content=content,
                parent_comment=parent_comment
            )
            if parent_comment.author != request.user:
                Notification.objects.create(user=parent_comment.author, sender=request.user, comment=new_comment, notification_type='comment')
            ancestor = parent_comment
            while ancestor:
                ancestor.reply_count += 1
                ancestor.save()
                ancestor = ancestor.parent_comment
    return redirect('post_detail', post_id=parent_comment.post.id)

#举报帖子
@require_POST
@login_required
def report_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    # 创建举报记录
    Report.objects.create(user=request.user, report_type='post', report_id=post_id, description=f'举报帖子：{post.content[:20]}')
    return JsonResponse({'message': '举报成功'})

#举报评论
@login_required
def report_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    # 创建举报记录
    Report.objects.create(user=request.user, report_type='comment', report_id=comment_id, description=f'举报评论：{comment.content}')
    return JsonResponse({'message': '举报成功'})
#删帖
@login_required
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.user == post.author:
        post.delete()
        #减活跃值
        request.user.profile.activity_points -= 2
        request.user.profile.save()
        return JsonResponse({'message': '删除成功'})
    return JsonResponse({'message': '无权删除'}, status=403)

#删评
@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user == comment.author:
        post = comment.post
        descendants_count = comment.delete_with_descendants()
        if comment.parent_comment:
            ancestor = comment.parent_comment
            while ancestor:
                ancestor.reply_count -= descendants_count
                ancestor.save()
                ancestor = ancestor.parent_comment
        else:
            post.comments_count -= descendants_count
            post.save()
        #减活跃值
        request.user.profile.activity_points -= 1
        request.user.profile.save()
        return JsonResponse({'message': '删除成功'})
    return JsonResponse({'message': '无权删除'}, status=403)

#用户主页
@login_required
def user_profile(request, user_id):
    user = get_object_or_404(User, id=user_id)
    posts = Post.objects.filter(author=user)
    bookmarks = Bookmark.objects.filter(user=user)
   #wzx 
    # 获取与当前用户有关的所有聊天对象的ID
    chat_partners_ids = PrivateMessage.objects.filter(
        Q(sender=user) | Q(receiver=user)
    ).values_list('sender', 'receiver')
    #关注
    profile = user.profile
    followers = profile.followers.all()
    following = Profile.objects.filter(followers=profile)
    is_following = request.user.profile in followers

    # 将所有 ID 转换为单一列表并去重
    chat_partners_ids = set(id for ids in chat_partners_ids for id in ids)

    # 查询用户对象，排除当前用户
    chat_partners = User.objects.filter(id__in=chat_partners_ids).exclude(id=user.id)

    # 获取当前用户拉黑的所有用户
    blocked_users = Blacklist.objects.filter(user=user).values_list('blocked_user', flat=True)
    blocked_users_list = User.objects.filter(id__in=blocked_users)
    
    superadmin = User.objects.filter(is_superuser=True).first()
    return render(request, 'wall/user_profile.html', {
        'user': user,
        'posts': posts,
        'bookmarks': bookmarks,
        'chat_partners': chat_partners,
        'blocked_users': blocked_users_list,
        'superadmin': superadmin,
        'followers': followers,
        'following': following,
        'is_following': is_following
    })#wzx


#注册，登录，登出
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # 确保登录时创建 Profile
            Profile.objects.get_or_create(user=user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

#消息
@login_required
def messages(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'wall/messages.html', {'notifications': notifications})

#修改主页信息
@login_required
def edit_profile(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        if 'avatar' in request.FILES:
            profile.avatar = request.FILES['avatar']
        profile.gender = request.POST.get('gender', profile.gender)
        profile.save()

        username = request.POST.get('username')
        if username and username != request.user.username:
            request.user.username = username
            request.user.save()

        return redirect('user_profile', user_id=request.user.id)

    context = {
        'profile': profile,
        'is_gender_unknown': profile.gender == 'unknown',
        'is_gender_male': profile.gender == 'male',
        'is_gender_female': profile.gender == 'female',
    }
    return render(request, 'wall/edit_profile.html', context)

#wzx begin
from .models import PrivateMessage
from django.db.models import Q
from .forms import PrivateMessageForm #lwb

@login_required
def chat_view(request, user_id):
    # 获取聊天对象
    other_user = get_object_or_404(User, id=user_id)
    
    if is_blocked(request.user, other_user):
        return HttpResponseForbidden("You cannot chat with this user.")
    

    if request.method == "POST":
        form = PrivateMessageForm(request.POST, request.FILES)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = other_user
            message.save()
            return redirect('chat', user_id=other_user.id)
    else:
        form = PrivateMessageForm()

    # 获取与此用户的聊天记录，按时间排序
    messages = PrivateMessage.objects.filter(
        Q(sender=request.user, receiver=other_user) | Q(sender=other_user, receiver=request.user)
    ).order_by('timestamp')
    
    

    context = {
        'other_user': other_user,
        'messages': messages,
        'form': form  # 添加表单到上下文lwb
    }

    return render(request, 'wall/chat.html', context)


from django.http import HttpResponseRedirect
from django.urls import reverse

@login_required
def send_message(request, user_id):
    # 获取聊天对象，确保用户存在
    chat_user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        form = PrivateMessageForm(request.POST, request.FILES)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = chat_user
            message.save()
            return redirect('chat', user_id=chat_user.id)
    else:
        form = PrivateMessageForm()

    messages = PrivateMessage.objects.filter(
        Q(sender=request.user, receiver=chat_user) |
        Q(sender=chat_user, receiver=request.user)
    ).order_by('timestamp')

    return render(request, 'wall/chat.html', {
        'other_user': chat_user,
        'messages': messages,
        'form': form  # 添加表单到上下文
    })


@login_required
def follow_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    profile = request.user.profile
    if profile != target_user.profile:
        profile.following.add(target_user.profile)
        return JsonResponse({'status': 'followed'})
    return JsonResponse({'status': 'error'})

@login_required
def unfollow_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    profile = request.user.profile
    if profile != target_user.profile:
        profile.following.remove(target_user.profile)
        return JsonResponse({'status': 'unfollowed'})
    return JsonResponse({'status': 'error'})
#wzx end


#高博文start
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.db.models import Q  # 导入 Q 对象用于进行复杂的查询
from django.utils.timezone import now
import logging
from .models import Team, TeamRequest
from .forms import TeamForm  # 创建了团队表单类

# 设置日志
logger = logging.getLogger(__name__)

@login_required
def create_or_join_team(request):
    if request.method == "POST":
        if 'create_team' in request.POST:
            # 创建新团队
            form = TeamForm(request.POST)
            if form.is_valid():
                team = form.save(commit=False)
                team.leader = request.user
                team.save()
                team.members.add(request.user)  # 将当前用户加入新创建的团队
                return redirect('team_home', team_id=team.id)
        elif 'join_team' in request.POST:
            # 处理加入现有团队的逻辑
            team_id = request.POST.get('team_id')
            team = get_object_or_404(Team, id=team_id)

            # 检查团队是否活跃（未超出终止时间）
            if not team.is_active():
                return render(request, 'create_or_join_team.html', {
                    'teams': Team.objects.filter(end_time__gt=now()),  # 只显示活跃团队
                    'error': "该团队已过期，无法申请加入。"
                })

            # 检查用户是否已经是该团队的成员
            if request.user in team.members.all():
                return render(request, 'create_or_join_team.html', {
                    'teams': Team.objects.filter(end_time__gt=now()),
                    'error': "你已经是该团队的成员，无法再次加入。"
                })

            # 检查是否已有待处理的请求
            if TeamRequest.objects.filter(team=team, user=request.user, status='pending').exists():
                return render(request, 'create_or_join_team.html', {
                    'teams': Team.objects.filter(end_time__gt=now()),
                    'error': "你已经提交了加入请求，等待队长处理。"
                })

            if team.is_full():
                return render(request, 'create_or_join_team.html', {
                    'teams': Team.objects.filter(end_time__gt=now()),
                    'error': "队伍已满，无法加入"
                })
            else:
                # 创建加入请求
                TeamRequest.objects.create(team=team, user=request.user, status='pending')
                return redirect('pending_request', team_id=team.id)
    else:
        form = TeamForm()

        # 获取搜索关键词
        search_query = request.GET.get('search', '')

        if search_query:
            # 使用 Q 对象进行模糊查询，可以根据队伍名称或队长名字搜索，过滤活跃团队
            teams = Team.objects.filter(
                Q(name__icontains=search_query) | Q(leader__username__icontains=search_query),
                end_time__gt=now()  # 只显示未过期的团队
            )
        else:
            teams = Team.objects.filter(end_time__gt=now())  # 只显示未过期的团队

        return render(request, 'create_or_join_team.html', {
            'form': form,
            'teams': teams,
            'search_query': search_query
        })


@login_required
def team_home(request, team_id):
    """
    允许用户访问其已加入的团队主页。
    """
    # 获取当前团队
    team = get_object_or_404(Team, id=team_id)
    # 获取用户参与的所有团队
    user_teams = request.user.teams.all()

    return render(request, 'team/team_home.html', {
        'team': team,
        'user_teams': user_teams,
    })


@login_required
def manage_team(request, team_id):
    team = get_object_or_404(Team, id=team_id)

    # 确保用户是队长
    if request.user != team.leader:
        return HttpResponseForbidden("只有队长可以管理队伍")

    # 当前时间
    current_time = now()

    # 处理解散团队
    if 'delete_team' in request.POST:
        logger.info(f"Team '{team.name}' (ID: {team.id}) was deleted by user '{request.user.username}'.")
        team.delete()
        return redirect('home')

    # 处理修改团队
    if 'edit_team' in request.POST:
        form = TeamForm(request.POST, instance=team)
        if form.is_valid():
            new_max_members = form.cleaned_data['max_members']
            new_end_time = form.cleaned_data['end_time']

            # 验证最大成员数是否小于当前成员数
            if new_max_members < team.members.count():
                pending_requests = team.requests.filter(status='pending')
                members = team.members.all()
                return render(request, 'team/manage_team.html', {
                    'team': team,
                    'members': members,
                    'pending_requests': pending_requests,
                    'form': form,
                    'error': f"最大成员数不能小于当前团队人数（{team.members.count()}）。",
                })

            # 验证终止时间是否大于当前时间
            if new_end_time <= current_time:
                pending_requests = team.requests.filter(status='pending')
                members = team.members.all()
                return render(request, 'team/manage_team.html', {
                    'team': team,
                    'members': members,
                    'pending_requests': pending_requests,
                    'form': form,
                    'error': "终止时间必须大于当前时间。",
                    'now': now(),  # 传递当前时间
                })

            # 保存表单数据
            form.save()
            logger.info(f"Team '{team.name}' (ID: {team.id}) was updated by user '{request.user.username}'.")
            return redirect('manage_team', team_id=team.id)
    else:
        form = TeamForm(instance=team)

    pending_requests = team.requests.filter(status='pending')
    members = team.members.all()

    return render(request, 'team/manage_team.html', {
        'team': team,
        'members': members,
        'pending_requests': pending_requests,
        'form': form,
        'now': now(),  # 传递当前时间，用于显示提醒
    })


@login_required
def team_home(request, team_id):
    """
    允许用户访问其已加入的团队主页。
    """
    # 获取当前团队
    team = get_object_or_404(Team, id=team_id)
    # 获取用户参与的所有团队
    user_teams = request.user.teams.all()

    return render(request, 'team/team_home.html', {
        'team': team,
        'user_teams': user_teams,
    })


@login_required
def remove_member(request, team_id, member_id):
    team = get_object_or_404(Team, id=team_id)
    if request.user != team.leader:
        return HttpResponseForbidden("只有队长可以移除队员")
    
    member = get_object_or_404(User, id=member_id)
    if member == team.leader:
        return HttpResponseForbidden("队长不能移除自己")
    
    team.members.remove(member)
    return redirect('manage_team', team_id=team.id)

@login_required
def review_request(request, request_id, action):
    team_request = get_object_or_404(TeamRequest, id=request_id)
    if request.user != team_request.team.leader:
        return HttpResponseForbidden("只有队长可以审核申请")
    
    if action == 'approve' and not team_request.team.is_full():
        team_request.team.members.add(team_request.user)
        team_request.status = 'approved'
    elif action == 'reject':
        team_request.status = 'rejected'
    team_request.save()
    
    return redirect('manage_team', team_id=team_request.team.id)

# 队员退出团队
@login_required
def leave_team(request, team_id):
    """
    允许队员退出团队（队长不能退出）。
    """
    team = get_object_or_404(Team, id=team_id)

    # 确保用户是团队成员
    if request.user not in team.members.all():
        return HttpResponseForbidden("您不是该团队的成员，无法退出。")

    # 队长不能退出团队
    if request.user == team.leader:
        return HttpResponseForbidden("队长无法退出团队。如果想解散团队，请在管理页面操作。")

    # 移除用户
    team.members.remove(request.user)
    return redirect('create_or_join_team')

from django.utils import timezone

@login_required
def pending_request(request, team_id):
    # 获取团队信息
    team = get_object_or_404(Team, id=team_id)

    # 检查用户是否已经是该团队的成员
    if request.user in team.members.all():
        return render(request, 'team/pending_request.html', {
            'team': team,
            'error': "您已经是该团队的成员，无法再次申请加入。"
        })

    # 检查用户是否已经申请该团队并且申请仍处于待处理状态
    existing_request = TeamRequest.objects.filter(team=team, user=request.user, status='pending').first()

    if existing_request:
        # 如果已有待处理申请，显示相应信息
        return render(request, 'team/pending_request.html', {
            'team': team,
            'existing_request': existing_request
        })

    # 终止时间提醒（如果终止时间在24小时内）
    now = timezone.now()
    time_remaining = team.end_time - now

    # 计算剩余天数、小时数、分钟数
    days_remaining = time_remaining.days
    hours_remaining = time_remaining.seconds // 3600
    minutes_remaining = (time_remaining.seconds % 3600) // 60

    # 格式化剩余时间
    formatted_time_remaining = f"{days_remaining}天 {hours_remaining}小时 {minutes_remaining}分钟"

    # 判断是否需要显示终止时间提醒
    show_end_time_warning = time_remaining <= timezone.timedelta(days=1)

    # 如果用户尚未申请，则显示加入申请表单
    if request.method == 'POST':
        message = request.POST.get('message', '')
        # 创建新的团队申请
        TeamRequest.objects.create(
            team=team,
            user=request.user,
            message=message,
            status='pending'
        )
        return redirect('team_home', team_id=team.id)  # 或者跳转到其他页面，例如申请成功页面

    # 渲染页面时传递终止时间警告以及团队信息
    return render(request, 'team/pending_request.html', {
        'team': team,
        'show_end_time_warning': show_end_time_warning,  # 传递终止时间提醒
        'time_remaining': formatted_time_remaining,  # 剩余时间（格式为天、小时、分钟）
        'formatted_end_time': team.end_time.strftime('%Y-%m-%d %H:%M:%S'),  # 格式化团队的终止时间
    })

@login_required
def handle_join_request(request, team_id):
    team = get_object_or_404(Team, id=team_id)

    # 确保只有队长可以处理加入请求
    if request.user != team.leader:
        return HttpResponseForbidden("只有队长可以处理加入请求")

    if request.method == "POST":
        action = request.POST.get('action')
        user_id = request.POST.get('user_id')

        if action not in ['approve', 'reject', 'remove']:
            return HttpResponseForbidden("无效的操作")

        target_user = get_object_or_404(User, id=user_id)

        if action == "approve":
            # 批准请求
            if team.is_full():
                return HttpResponseForbidden("团队已满，无法批准加入请求")
            team.members.add(target_user)
            Notification.objects.create(
                user=target_user,  # 消息接收用户
                sender=request.user,  # 消息发送用户（队长）
                team=team,
                notification_type='team_request_approved',
                message=f"您已被批准加入团队 {team.name}。",
            )
        elif action == "reject":
            # 拒绝请求
            Notification.objects.create(
                user=target_user,
                sender=request.user,
                team=team,
                notification_type='team_request_rejected',
                message=f"您加入团队 {team.name} 的请求被拒绝。",
            )
        elif action == "remove":
            # 移除成员
            if target_user == team.leader:
                return HttpResponseForbidden("队长不能被移除")
            team.members.remove(target_user)
            Notification.objects.create(
                user=target_user,
                sender=request.user,
                team=team,
                notification_type='team_member_removed',
                message=f"您已被移出团队 {team.name}。",
            )
        return redirect('team_detail', team_id=team.id)



#李卓伦 start
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseForbidden
from .models import Blacklist
from django.db.models import Q  # 添加导入

def is_blocked(user, target_user):  # 添加 is_blocked 函数定义
    return Blacklist.objects.filter(user=user, blocked_user=target_user).exists() or \
           Blacklist.objects.filter(user=target_user, blocked_user=user).exists()

@login_required
def block_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    if target_user != request.user:
        Blacklist.objects.get_or_create(user=request.user, blocked_user=target_user)
    return redirect('user_profile', user_id=request.user.id)

from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

@login_required
def unblock_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    try:
        blacklist_entry = Blacklist.objects.get(user=request.user, blocked_user=target_user)
        blacklist_entry.delete()
        return redirect('user_profile', user_id=request.user.id)
    except Blacklist.DoesNotExist:
        return redirect('user_profile', user_id=request.user.id)



@login_required
def pin_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    # 确保用户是帖子作者
    if request.user == post.author:
        # 获取用户选择的置顶时长
        duration = request.POST.get('duration')  # 获取用户选择的时长
        if duration == '1':
            time_delta = timedelta(hours=1)
            activity_cost = 3
        elif duration == '5':
            time_delta = timedelta(hours=5)
            activity_cost = 6
        elif duration == '24':
            time_delta = timedelta(hours=24)
            activity_cost = 9
        else:
            return redirect('home')  # 如果没有选择有效的时长，重定向到主页

        # 检查活跃度是否足够
        if request.user.profile.activity_points < activity_cost:
            return redirect('home')  # 如果活跃度不足，重定向到主页

        # 扣除活跃度积分
        request.user.profile.activity_points -= activity_cost
        request.user.profile.save()

        # 将帖子置顶，设置置顶到期时间
        post.is_pinned = True
        post.pinned_until = timezone.now() + time_delta  # 使用用户选择的时长
        post.save()

    return redirect('home')  # 置顶后重定向到主页

@login_required
def unpin_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    # 确保用户是帖子作者
    if request.user == post.author:
        # 取消置顶
        post.unpin_post()

    return redirect('home')  # 取消置顶后重定向到主页

@login_required
def refresh_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    # 确保用户是帖子作者
    if request.user == post.author:
        # 检查活跃度积分是否足够
        if request.user.profile.activity_points < 1:
            return redirect('home')  # 如果活跃度不足，重定向到主页

        # 扣除活跃度积分
        request.user.profile.activity_points -= 1
        request.user.profile.save()

        # 更新帖子发布时间为当前时间
        post.created_at = timezone.now()
        post.save()

    return redirect('home')  # 更新后重定向到主页