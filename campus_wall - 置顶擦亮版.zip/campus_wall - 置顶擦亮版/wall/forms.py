from django import forms
from .models import Team
from django.utils.timezone import now
from .models import PrivateMessage

class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ['name', 'description', 'max_members', 'end_time']
        widgets = {
            'end_time': forms.DateTimeInput(attrs={'type': 'datetime-local'})  # 使用 datetime-local 输入类型
        }

    def clean_max_members(self):
        """确保最大成员数不小于当前团队人数。"""
        max_members = self.cleaned_data.get('max_members')
        team = self.instance  # 获取正在编辑的团队实例（如果是编辑表单）
        if team and max_members < team.members.count():
            raise forms.ValidationError(f"最大成员数不能小于当前团队人数（{team.members.count()}）。")
        return max_members

    def clean_end_time(self):
        """确保结束时间不早于当前时间。"""
        end_time = self.cleaned_data.get('end_time')
        if end_time and end_time <= now():
            raise forms.ValidationError("终止时间必须大于当前时间。")
        return end_time

#lwb
class PrivateMessageForm(forms.ModelForm):
    class Meta:
        model = PrivateMessage
        fields = ['message', 'image']

    message = forms.CharField(widget=forms.Textarea, required=False)
    image = forms.ImageField(label='Attach an image (optional)', required=False)