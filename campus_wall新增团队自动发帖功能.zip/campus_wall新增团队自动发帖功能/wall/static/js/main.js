$(document).ready(function () {
    $('.options-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $('#options-container-' + id + ' .options-btn').hide(); // 隐藏“...”按钮
        $('#options-' + id).show(); // 显示“删除该帖”和“取消”按钮
    });

    $('.cancel-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $('#options-' + id).hide(); // 隐藏“删除该帖”和“取消”按钮
        $('#options-container-' + id + ' .options-btn').show(); // 显示“...”按钮
    });

    $('.delete-post-btn').click(function () {
        var postId = $(this).data('post-id');
        $.ajax({
            url: '/delete_post/' + postId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                alert('删除成功');
                window.location.href = '/';
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.delete-comment-btn').click(function () {
        var commentId = $(this).data('comment-id');
        $.ajax({
            url: '/delete_comment/' + commentId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                alert(response.message);
                location.reload(); // 删除成功后刷新页面
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    });

    $('.like-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        var likeCount = $('#like-count-' + id);
        var img = $(this);
        $.ajax({
            url: postId ? '/post/' + postId + '/like/' : '/comment/' + commentId + '/like/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                likeCount.text(response.count);
                img.attr('src', response.liked ? '/static/thumbed.jpg' : '/static/thumb.jpg');
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.bookmark-btn').click(function () {
        var postId = $(this).data('post-id');
        var img = $(this);
        $.ajax({
            url: '/post/' + postId + '/bookmark/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                img.attr('src', response.bookmarked ? '/static/bookmarked.jpg' : '/static/bookmark.jpg');
                $('#bookmark-count-' + postId).text(response.count);
            }
        });
    });


    $('.report-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $.ajax({
            url: postId ? '/post/' + postId + '/report/' : '/report_comment/' + commentId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': csrftoken },
            success: function (response) {
                alert('举报成功');
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.comment-reply-btn').click(function () {
        var commentId = $(this).data('comment-id');
        var replyForm = $('#reply-form-' + commentId);
        if (replyForm.is(':visible')) {
            replyForm.hide();
        } else {
            replyForm.show();
        }
    });

    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    var csrftoken = getCookie('csrftoken');
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });

    $(document).ready(function() {
        console.log("main.js loaded"); // 确保JS文件被加载
    
        $('#toggleButton').click(function() {
            var content = $('#content');
            var buttonText = $(this);
    
            if (content.is(':hidden')) {
                content.show(); // 展开内容
                buttonText.text('隐藏内容'); // 修改按钮文字
            } else {
                content.hide(); // 隐藏内容
                buttonText.text('展开内容'); // 恢复按钮文字
            }
        });
    });
    $(document).ready(function() {
        console.log("main.js loaded"); // 确保JS文件被加载
    
        // 默认显示帖子内容并给对应按钮添加 active 类
        $('#posts').show();
        $('.tab-link[data-tab="posts"]').addClass('active');
    
        // 点击导航项切换内容
        $('.tab-link').click(function() {
            // 移除所有导航项的 active 类
            $('.tab-link').removeClass('active');
    
            // 添加当前点击项的 active 类
            $(this).addClass('active');
    
            // 获取目标 tab 的 id
            var targetTab = $(this).data('tab');
    
            // 隐藏所有的 tab 内容
            $('.tab-content').hide();
    
            // 显示对应的 tab 内容
            $('#' + targetTab).show();
        });
    });
    
    $(document).ready(function () {
        $('#follow-btn').on('click', function () {
            var $this = $(this);
            var userId = $this.data('user-id');
            var action = $this.text().trim() === '关注' ? 'follow' : 'unfollow';
            
            $.ajax({
                url: '/' + action + '/' + userId + '/',
                type: 'POST',
                headers: { 'X-CSRFToken': '{{ csrf_token }}' },
                success: function (data) {
                    if (data.status === 'followed') {
                        $this.text('取消关注');
                    } else if (data.status === 'unfollowed') {
                        $this.text('关注');
                    }
                },
                error: function () {
                    alert('操作失败，请稍后重试。');
                }
            });
        });
    });

    // 接单按钮点击事件
    $('#acceptTaskBtn').click(function(event) {
        event.preventDefault();  // 阻止默认跳转行为

        var taskId = $(this).data('task-id');
        
        // 发送 AJAX 请求
        $.ajax({
            url: '/task/' + taskId + '/accept/',  // 请求 URL
            method: 'POST',
            data: {
                'csrfmiddlewaretoken': '{{ csrf_token }}',
            },
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message); // 弹窗显示成功信息
                    window.location.href = '/task/' + response.task_id + '/'; // 重定向到任务详情页面
                } else {
                    alert(response.message); // 弹窗显示错误信息
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                alert("发生了错误，请稍后重试。");
            }
        });
    });

    // 确认完成按钮点击事件
    $('#confirmCompletionBtn').click(function(event) {
        event.preventDefault();

        var taskId = $(this).data('task-id');
        
        $.ajax({
            url: '/task/' + taskId + '/confirm-completion/', // 请求 URL
            method: 'POST',
            data: {
                'csrfmiddlewaretoken': '{{ csrf_token }}',
            },
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message); // 弹窗显示任务更新信息
                    window.location.href = '/task/' + response.task_id + '/'; // 重定向到任务详情页面
                } else {
                    alert(response.message); // 弹窗显示错误信息
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                alert("发生了错误，请稍后重试。");
            }
        });
    });

    // 发布者确认任务完成按钮点击事件
    $('#verifyCompletionBtn').click(function(event) {
        event.preventDefault();

        var taskId = $(this).data('task-id');
        var isSuccess = $(this).data('is-success');

        $.ajax({
            url: '/task/' + taskId + '/verify-completion/' + isSuccess + '/', // 请求 URL
            method: 'POST',
            data: {
                'csrfmiddlewaretoken': '{{ csrf_token }}',
            },
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message); // 弹窗显示任务更新信息
                    window.location.href = '/task/' + response.task_id + '/'; // 重定向到任务详情页面
                } else {
                    alert(response.message); // 弹窗显示错误信息
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                alert("发生了错误，请稍后重试。");
            }
        });
    });
});
