from django import forms
from .models import Team
from django.utils.timezone import now
from .models import PrivateMessage

class TeamForm(forms.ModelForm):
   
    auto_create_post = forms.BooleanField(required=False, label="自动发帖", initial=False)  # 自动发帖变量
   
    class Meta:
        model = Team
        fields = ['name', 'description', 'max_members', 'end_time', 'leader']  # 包括 'leader' 字段
        widgets = {
            'end_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'leader': forms.HiddenInput()  # 将 'leader' 字段设置为隐藏
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)  # 从 kwargs 中提取 user 参数
        super().__init__(*args, **kwargs)

        if self.user:
            # 将当前用户设置为默认的 leader
            self.instance.leader = self.user  # 设置默认的队长
            self.fields['leader'].initial = self.user  # 设置字段初始值为当前用户
            # 设置为只读，并隐藏 'leader' 字段
            self.fields['leader'].widget.attrs['readonly'] = 'readonly'  # 设置为只读
            self.fields['leader'].widget.attrs['hidden'] = 'hidden'  # 隐藏该字段

    def clean_max_members(self):
        """确保最大成员数不小于当前团队人数。"""
        max_members = self.cleaned_data.get('max_members')
        if self.instance and self.instance.pk:  # 确保是编辑表单
            team = self.instance  # 获取正在编辑的团队实例
            if max_members < team.members.count():
                raise forms.ValidationError(f"最大成员数不能小于当前团队人数（{team.members.count()}）。")
        return max_members

    def clean_end_time(self):
        """确保结束时间不早于当前时间。"""
        end_time = self.cleaned_data.get('end_time')
        if end_time and end_time <= now():
            raise forms.ValidationError("终止时间必须大于当前时间。")
        return end_time


#lwb
class PrivateMessageForm(forms.ModelForm):
    class Meta:
        model = PrivateMessage
        fields = ['message', 'image']

    message = forms.CharField(widget=forms.Textarea, required=False)
    image = forms.ImageField(label='Attach an image (optional)', required=False)