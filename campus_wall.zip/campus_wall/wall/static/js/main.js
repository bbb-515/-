$(document).ready(function () {
    $('.options-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $('#options-container-' + id + ' .options-btn').hide(); // 隐藏“...”按钮
        $('#options-' + id).show(); // 显示“删除该帖”和“取消”按钮
    });

    $('.cancel-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $('#options-' + id).hide(); // 隐藏“删除该帖”和“取消”按钮
        $('#options-container-' + id + ' .options-btn').show(); // 显示“...”按钮
    });

    $('.delete-post-btn').click(function () {
        var postId = $(this).data('post-id');
        $.ajax({
            url: '/delete_post/' + postId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                alert('删除成功');
                window.location.href = '/';
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.delete-comment-btn').click(function () {
        var commentId = $(this).data('comment-id');
        $.ajax({
            url: '/delete_comment/' + commentId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                alert(response.message);
                location.reload(); // 删除成功后刷新页面
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    });

    $('.like-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        var likeCount = $('#like-count-' + id);
        var img = $(this);
        $.ajax({
            url: postId ? '/post/' + postId + '/like/' : '/comment/' + commentId + '/like/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                likeCount.text(response.count);
                img.attr('src', response.liked ? '/static/thumbed.jpg' : '/static/thumb.jpg');
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.bookmark-btn').click(function () {
        var postId = $(this).data('post-id');
        var img = $(this);
        $.ajax({
            url: '/post/' + postId + '/bookmark/',
            method: 'POST',
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
            success: function (response) {
                img.attr('src', response.bookmarked ? '/static/bookmarked.jpg' : '/static/bookmark.jpg');
                $('#bookmark-count-' + postId).text(response.count);
            }
        });
    });


    $('.report-btn').click(function () {
        var postId = $(this).data('post-id');
        var commentId = $(this).data('comment-id');
        var id = postId ? postId : commentId;
        $.ajax({
            url: postId ? '/post/' + postId + '/report/' : '/report_comment/' + commentId + '/',
            method: 'POST',
            headers: { 'X-CSRFToken': csrftoken },
            success: function (response) {
                alert('举报成功');
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    });

    $('.comment-reply-btn').click(function () {
        var commentId = $(this).data('comment-id');
        var replyForm = $('#reply-form-' + commentId);
        if (replyForm.is(':visible')) {
            replyForm.hide();
        } else {
            replyForm.show();
        }
    });

    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    var csrftoken = getCookie('csrftoken');
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        }
    });
});
