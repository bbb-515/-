from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User  
from .models import Profile, Post, Comment, Bookmark,Notification,Report
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.conf import settings
from django.db.models import Q, Count
from .models import Blacklist 
from django.contrib.auth.models import AnonymousUser




def home(request):
    query = request.GET.get('q', '')  # 获取搜索查询，如果没有则为空串

    # 如果用户是匿名的，设置blocked_users为空列表
    if isinstance(request.user, AnonymousUser):
        blocked_users = []
    else:
        blocked_users = Blacklist.objects.filter(user=request.user).values_list('blocked_user', flat=True)

    # 查询字段
    if query:
        posts = Post.objects.filter(Q(content__icontains=query) | Q(author__username__icontains=query)).exclude(author__id__in=blocked_users)
    else:
        posts = Post.objects.all().exclude(author__id__in=blocked_users)
    
    liked_posts = request.user.liked_posts.all() if request.user.is_authenticated else []
    bookmarked_posts = request.user.bookmarked_posts.all() if request.user.is_authenticated else []

    context = {
        'posts': posts,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
    }
    return render(request, 'wall/home.html', context)

#创建帖子
@login_required
def create_post(request):
    if request.method == 'POST':
        content = request.POST['content']
        post = Post.objects.create(author=request.user, content=content)
        request.user.profile.activity_points += 2
        request.user.profile.save()
        return redirect('home')
    return render(request, 'wall/create_post.html')

#帖子详情页
@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.views += 1  # 增加帖子浏览量
    post.save()
    comments = Comment.objects.filter(post=post).order_by('created_at')
    liked_posts = request.user.liked_posts.all()
    bookmarked_posts = request.user.bookmarked_posts.all()
    liked_comments = request.user.liked_comments.all()

    context = {
        'post': post,
        'comments': comments,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
        'liked_comments': liked_comments,
    }
    return render(request, 'wall/post_detail.html', context)
#点赞和取消点赞/对帖子
@require_POST
@login_required
def like_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if post.author != request.user:
        if request.user in post.likes.all():
            post.likes.remove(request.user)
            liked = False
            #减活跃值
            post.author.profile.activity_points -= 1
            post.author.profile.save()
        else:
            post.likes.add(request.user)
            liked = True       
            Notification.objects.create(user=post.author, sender=request.user, post=post, notification_type='like')
            #减活跃值
            post.author.profile.activity_points += 1
            post.author.profile.save()
        return JsonResponse({'liked': liked, 'count': post.likes.count()})
    else:
        liked = False #不能给自己点赞
        return JsonResponse({'liked': liked, 'count': post.likes.count()})    
    
#点赞和取消点赞/对评论
@require_POST
@login_required
def like_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if comment.author != request.user:
        if request.user in comment.likes.all():
            comment.likes.remove(request.user)
            liked = False
            comment.like_count -= 1
            #减活跃值
            comment.author.profile.activity_points -= 1
            comment.author.profile.save()
        else:
            comment.likes.add(request.user)
            liked = True
            comment.like_count += 1
            if comment.author != request.user:
                Notification.objects.create(user=comment.author, sender=request.user, comment=comment, notification_type='like')
            #加活跃值
            comment.author.profile.activity_points += 1
            comment.author.profile.save()
        comment.save()
        return JsonResponse({'liked': liked, 'count': comment.like_count})
    else:
        liked = False  # 不能给自己点赞
        return JsonResponse({'liked': liked, 'count': comment.like_count})
    
#收藏和取消收藏/对帖子
@require_POST
@login_required
def bookmark_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    bookmark, created = Bookmark.objects.get_or_create(user=request.user, post=post)
    if not created:
        #加活跃值
        bookmark.post.author.profile.activity_points += 1
        bookmark.post.author.profile.save()
        bookmark.delete()
        post.bookmarks.remove(request.user)
        post.bookmark_count -= 1
        bookmarked = False
    else:
        #减活跃值
        bookmark.post.author.profile.activity_points -= 1
        bookmark.post.author.profile.save()
        post.bookmarks.add(request.user)        
        post.bookmark_count += 1
        bookmarked = True
        Notification.objects.create(user=post.author, sender=request.user, post=post, notification_type='bookmark')
    post.save()
    return JsonResponse({'bookmarked': bookmarked, 'count': post.bookmark_count})


#评论/对帖子
@require_POST
@login_required
def comment_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        content = request.POST.get('content')
        #加活跃值
        request.user.profile.activity_points += 1
        request.user.profile.save()
        if content:
            comment = Comment.objects.create(post=post, author=request.user, content=content)
            if post.author != request.user:
                Notification.objects.create(user=post.author, sender=request.user, post=post, comment=comment, notification_type='comment')
            post.comments_count += 1
            post.save()
    return redirect('post_detail', post_id=post.id)

#评论/对评论
@login_required
def comment_reply(request, comment_id):
    parent_comment = get_object_or_404(Comment, id=comment_id)
    if request.method == 'POST':
        content = request.POST.get('content')
        #加活跃值
        request.user.profile.activity_points += 1
        request.user.profile.save()
        if content:
            new_comment = Comment.objects.create(
                post=parent_comment.post,
                author=request.user,
                content=content,
                parent_comment=parent_comment
            )
            if parent_comment.author != request.user:
                Notification.objects.create(user=parent_comment.author, sender=request.user, comment=new_comment, notification_type='comment')
            ancestor = parent_comment
            while ancestor:
                ancestor.reply_count += 1
                ancestor.save()
                ancestor = ancestor.parent_comment
    return redirect('post_detail', post_id=parent_comment.post.id)

#举报帖子
@require_POST
@login_required
def report_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    # 创建举报记录
    Report.objects.create(user=request.user, report_type='post', report_id=post_id, description=f'举报帖子：{post.content[:20]}')
    return JsonResponse({'message': '举报成功'})

#举报评论
@login_required
def report_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    # 创建举报记录
    Report.objects.create(user=request.user, report_type='comment', report_id=comment_id, description=f'举报评论：{comment.content}')
    return JsonResponse({'message': '举报成功'})
#删帖
@login_required
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.user == post.author:
        post.delete()
        #减活跃值
        request.user.profile.activity_points -= 2
        request.user.profile.save()
        return JsonResponse({'message': '删除成功'})
    return JsonResponse({'message': '无权删除'}, status=403)

#删评
@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user == comment.author:
        post = comment.post
        descendants_count = comment.delete_with_descendants()
        if comment.parent_comment:
            ancestor = comment.parent_comment
            while ancestor:
                ancestor.reply_count -= descendants_count
                ancestor.save()
                ancestor = ancestor.parent_comment
        else:
            post.comments_count -= descendants_count
            post.save()
        #减活跃值
        request.user.profile.activity_points -= 1
        request.user.profile.save()
        return JsonResponse({'message': '删除成功'})
    return JsonResponse({'message': '无权删除'}, status=403)

#用户主页
@login_required
def user_profile(request, user_id):
    user = get_object_or_404(User, id=user_id)
    posts = Post.objects.filter(author=user)
    bookmarks = Bookmark.objects.filter(user=user)
   #wzx 
    # 获取与当前用户有关的所有聊天对象的ID
    chat_partners_ids = PrivateMessage.objects.filter(
        Q(sender=user) | Q(receiver=user)
    ).values_list('sender', 'receiver')

    # 将所有 ID 转换为单一列表并去重
    chat_partners_ids = set(id for ids in chat_partners_ids for id in ids)

    # 查询用户对象，排除当前用户
    chat_partners = User.objects.filter(id__in=chat_partners_ids).exclude(id=user.id)

    # 获取当前用户拉黑的所有用户
    blocked_users = Blacklist.objects.filter(user=user).values_list('blocked_user', flat=True)
    blocked_users_list = User.objects.filter(id__in=blocked_users)

    return render(request, 'wall/user_profile.html', {
        'user': user,
        'posts': posts,
        'bookmarks': bookmarks,
        'chat_partners': chat_partners,
        'blocked_users': blocked_users_list
    })#wzx


#注册，登录，登出
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # 确保登录时创建 Profile
            Profile.objects.get_or_create(user=user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

#消息
@login_required
def messages(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'wall/messages.html', {'notifications': notifications})

#修改主页信息
@login_required
def edit_profile(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        if 'avatar' in request.FILES:
            profile.avatar = request.FILES['avatar']
        profile.gender = request.POST.get('gender', profile.gender)
        profile.save()

        username = request.POST.get('username')
        if username and username != request.user.username:
            request.user.username = username
            request.user.save()

        return redirect('user_profile', user_id=request.user.id)

    context = {
        'profile': profile,
        'is_gender_unknown': profile.gender == 'unknown',
        'is_gender_male': profile.gender == 'male',
        'is_gender_female': profile.gender == 'female',
    }
    return render(request, 'wall/edit_profile.html', context)

#wzx begin
from .models import PrivateMessage
from django.db.models import Q

@login_required
def chat_view(request, user_id):
    # 获取聊天对象
    other_user = get_object_or_404(User, id=user_id)
    
    if is_blocked(request.user, other_user):
        return HttpResponseForbidden("You cannot chat with this user.")
    

    if request.method == "POST":
        message = request.POST.get("message")
        if message:
            PrivateMessage.objects.create(
                sender=request.user,
                receiver=other_user,
                message=message
            )
    # 获取与此用户的聊天记录，按时间排序
    messages = PrivateMessage.objects.filter(
        Q(sender=request.user, receiver=other_user) | Q(sender=other_user, receiver=request.user)
    ).order_by('timestamp')

    context = {
        'other_user': other_user,
        'messages': messages
    }

    return render(request, 'wall/chat.html', context)


from django.http import HttpResponseRedirect
from django.urls import reverse

@login_required
def send_message(request, user_id):
    # 获取聊天对象，确保用户存在
    chat_user = get_object_or_404(User, id=user_id)

    # 查询当前用户和聊天对象之间的历史聊天记录
    messages = PrivateMessage.objects.filter(
        Q(sender=request.user, receiver=chat_user) |
        Q(sender=chat_user, receiver=request.user)
    ).order_by('timestamp')  # 按时间排序，最早的消息在前

    # 如果是 POST 请求，处理消息发送
    if request.method == 'POST':
        message_content = request.POST.get('message')
        if message_content:
            # 创建并保存新消息
            PrivateMessage.objects.create(
                sender=request.user,
                receiver=chat_user,
                message=message_content
            )
            # 重定向到聊天页面
            return HttpResponseRedirect(reverse('chat', args=[user_id]))

    # 渲染私信页面，传递历史消息和聊天对象到模板中
    return render(request, 'wall/chat.html', {
        #'chat_user': chat_user,
        'other_user': chat_user,
        'messages': messages,  # 传递历史聊天记录
    })

#wzx end


#高博文start
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import render, get_object_or_404
from .models import Team
from django.shortcuts import render, redirect
from .models import Team, TeamRequest
from .forms import TeamForm  # 假设你已经创建了团队表单类

# 创建或加入团队视图
@login_required
def create_or_join_team(request):
    if request.method == "POST":
        if 'create_team' in request.POST:
            # 创建新团队
            form = TeamForm(request.POST)
            if form.is_valid():
                team = form.save(commit=False)
                team.leader = request.user
                team.save()
                team.members.add(request.user)  # 将当前用户加入新创建的团队
                return redirect('team_home', team_id=team.id)
        elif 'join_team' in request.POST:
            # 加入现有团队
            team_id = request.POST.get('team_id')
            team = Team.objects.get(id=team_id)
            if team.is_full():
                return render(request, 'create_or_join_team.html', {
                    'teams': Team.objects.all(), 
                    'error': "队伍已满，无法加入"
                })
            else:
                # 发送加入请求
                TeamRequest.objects.create(team=team, user=request.user, status='pending')
                return redirect('team_home', team_id=team.id)
    else:
        form = TeamForm()
        teams = Team.objects.all()
        return render(request, 'create_or_join_team.html', {'form': form, 'teams': teams})


def team_home(request, team_id):
    team = get_object_or_404(Team, id=team_id)
    return render(request, 'team/team_home.html', {'team': team})

@login_required
def manage_team(request, team_id):
    team = get_object_or_404(Team, id=team_id)
    if request.user != team.leader:
        return HttpResponseForbidden("只有队长可以管理队伍")
    
    pending_requests = team.requests.filter(status='pending')
    members = team.members.all()
    return render(request, 'team/manage_team.html', {
        'team': team,
        'members': members,
        'pending_requests': pending_requests,
    })

@login_required
def remove_member(request, team_id, member_id):
    team = get_object_or_404(Team, id=team_id)
    if request.user != team.leader:
        return HttpResponseForbidden("只有队长可以移除队员")
    
    member = get_object_or_404(User, id=member_id)
    if member == team.leader:
        return HttpResponseForbidden("队长不能移除自己")
    
    team.members.remove(member)
    return redirect('manage_team', team_id=team.id)

@login_required
def review_request(request, request_id, action):
    team_request = get_object_or_404(TeamRequest, id=request_id)
    if request.user != team_request.team.leader:
        return HttpResponseForbidden("只有队长可以审核申请")
    
    if action == 'approve' and not team_request.team.is_full():
        team_request.team.members.add(team_request.user)
        team_request.status = 'approved'
    elif action == 'reject':
        team_request.status = 'rejected'
    team_request.save()
    
    return redirect('manage_team', team_id=team_request.team.id)

  
#李卓伦 start
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseForbidden
from .models import Blacklist
from django.db.models import Q  # 添加导入

def is_blocked(user, target_user):  # 添加 is_blocked 函数定义
    return Blacklist.objects.filter(user=user, blocked_user=target_user).exists() or \
           Blacklist.objects.filter(user=target_user, blocked_user=user).exists()

@login_required
def block_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    if target_user != request.user:
        Blacklist.objects.get_or_create(user=request.user, blocked_user=target_user)
    return redirect('user_profile', user_id=request.user.id)

from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

@login_required
def unblock_user(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    try:
        blacklist_entry = Blacklist.objects.get(user=request.user, blocked_user=target_user)
        blacklist_entry.delete()
        return redirect('user_profile', user_id=request.user.id)
    except Blacklist.DoesNotExist:
        return redirect('user_profile', user_id=request.user.id)
