from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User  
from .models import Profile, Post, Comment, Bookmark,Notification,Report
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.conf import settings
from django.db.models import Q, Count



def home(request):
    query = request.GET.get('q', '')  # 获取搜索查询，如果没有则为空串
    
    # 查询字段
    if query:
        posts = Post.objects.filter(Q(content__icontains=query) | Q(author__username__icontains=query))
    else:
        posts = Post.objects.all()
    
    liked_posts = request.user.liked_posts.all() if request.user.is_authenticated else []
    bookmarked_posts = request.user.bookmarked_posts.all() if request.user.is_authenticated else []

    context = {
        'posts': posts,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
    }
    return render(request, 'wall/home.html', context)

#创建帖子
@login_required
def create_post(request):
    if request.method == 'POST':
        content = request.POST['content']
        post = Post.objects.create(author=request.user, content=content)
        request.user.profile.activity_points += 2
        request.user.profile.save()
        return redirect('home')
    return render(request, 'wall/create_post.html')

#帖子详情页
@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.views += 1
    post.save()
    comments = Comment.objects.filter(post=post).order_by('created_at')
    liked_posts = request.user.liked_posts.all()
    bookmarked_posts = request.user.bookmarked_posts.all()
    liked_comments = request.user.liked_comments.all()

    context = {
        'post': post,
        'comments': comments,
        'liked_posts': liked_posts,
        'bookmarked_posts': bookmarked_posts,
        'liked_comments': liked_comments,
    }
    return render(request, 'wall/post_detail.html', context)


#用户主页
@login_required
def user_profile(request, user_id):
    user = get_object_or_404(User, id=user_id)
    posts = Post.objects.filter(author=user)
    bookmarks = Bookmark.objects.filter(user=user)
    return render(request, 'wall/user_profile.html', {'user': user, 'posts': posts, 'bookmarks': bookmarks})

#注册，登录，登出
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # 确保登录时创建 Profile
            Profile.objects.get_or_create(user=user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

#消息
@login_required
def messages(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'wall/messages.html', {'notifications': notifications})

#修改主页信息
@login_required
def edit_profile(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        if 'avatar' in request.FILES:
            profile.avatar = request.FILES['avatar']
        profile.gender = request.POST.get('gender', profile.gender)
        profile.save()

        username = request.POST.get('username')
        if username and username != request.user.username:
            request.user.username = username
            request.user.save()

        return redirect('user_profile', user_id=request.user.id)

    context = {
        'profile': profile,
        'is_gender_unknown': profile.gender == 'unknown',
        'is_gender_male': profile.gender == 'male',
        'is_gender_female': profile.gender == 'female',
    }
    return render(request, 'wall/edit_profile.html', context)

from .models import PrivateMessage
def chat_view(request, user_id):
    other_user = get_object_or_404(User, id=user_id)
    messages = PrivateMessage.objects.filter(
        sender__in=[request.user, other_user],
        receiver__in=[request.user, other_user]
    ).order_by('timestamp')

    context = {
        'other_user': other_user,
        'messages': messages
    }
    return render(request, 'chat.html', context)

from django.http import HttpResponseRedirect
from django.urls import reverse

@login_required
def send_message(request, user_id):
    # 获取聊天对象，使用 get_object_or_404 确保用户存在
    user = get_object_or_404(User, id=user_id)

    # 处理消息发送
    if request.method == 'POST':
        message_content = request.POST.get('message')
        if message_content:
            # 创建并保存消息
            PrivateMessage.objects.create(
                sender=request.user,
                receiver=user,
                message=message_content
            )
            # 发送完消息后重定向到聊天页面
            return HttpResponseRedirect(reverse('chat', args=[user_id]))

    # 渲染私信页面，传递用户信息到模板中
    return render(request, 'wall/chat.html', {
        'chat_user': user,
    })