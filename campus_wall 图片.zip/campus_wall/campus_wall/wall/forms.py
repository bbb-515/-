from django import forms
from .models import Team
from .models import PrivateMessage

class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ['name', 'description', 'max_members']

class PrivateMessageForm(forms.ModelForm):
    class Meta:
        model = PrivateMessage
        fields = ['message', 'image']

    message = forms.CharField(widget=forms.Textarea, required=False)
    image = forms.ImageField(label='Attach an image (optional)', required=False)