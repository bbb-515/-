from django.contrib import admin
from .models import Report,Profile, Post, Comment, Bookmark,Team

admin.site.register(Profile)
admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Bookmark)
admin.site.register(Report)
# 高博文 start
admin.site.register(Team)
# 高博文 end